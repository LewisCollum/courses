rm *~, *.cf, *.vcd, *.ghw, *.fst, *.html, *.xml
